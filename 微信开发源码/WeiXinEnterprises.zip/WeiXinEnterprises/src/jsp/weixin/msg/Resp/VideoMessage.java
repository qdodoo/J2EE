package jsp.weixin.msg.Resp;

/**
 * ��Ƶ��Ϣ
 * 
 * @author Engineer.Jsp
 * @date 2014.10.08*
 */
public class VideoMessage extends BaseMessage {
	// ��Ƶ
	private Video Video;

	public Video getVideo() {
		return Video;
	}

	public void setVideo(Video video) {
		Video = video;
	}
}
