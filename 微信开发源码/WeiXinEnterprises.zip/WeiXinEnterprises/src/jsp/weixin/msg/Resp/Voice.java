package jsp.weixin.msg.Resp;

/**
 * ����
 * 
 * @author Engineer.Jsp
 * @date 2014.10.08*
 */
public class Voice {
	// ý���ļ�id
	private String MediaId;

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}
}
