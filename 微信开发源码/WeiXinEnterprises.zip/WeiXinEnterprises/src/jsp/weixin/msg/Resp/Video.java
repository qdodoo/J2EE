package jsp.weixin.msg.Resp;

/**
 * ��Ƶ
 * 
 * @author Engineer.Jsp
 * @date 2014.10.08*
 */
public class Video {
	// ý���ļ�id
	private String MediaId;
	// ����ͼ��ý��id
	private String ThumbMediaId;

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}

	public String getThumbMediaId() {
		return ThumbMediaId;
	}

	public void setThumbMediaId(String thumbMediaId) {
		ThumbMediaId = thumbMediaId;
	}
}
