package jsp.weixin.msg.Resp;

/**
 * ͼƬ
 * 
 * @author Engineer.Jsp
 * @date 2014.10.08*
 */
public class Image {
	// ý���ļ�id
	private String MediaId;

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}
}
