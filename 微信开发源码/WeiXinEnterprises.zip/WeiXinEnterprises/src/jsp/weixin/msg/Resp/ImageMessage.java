package jsp.weixin.msg.Resp;

/**
 * ͼƬ��Ϣ
 * 
 * @author Engineer.Jsp
 * @date 2014.10.08*
 */
public class ImageMessage extends BaseMessage {
	// ͼƬ
	private Image Image;

	public Image getImage() {
		return Image;
	}

	public void setImage(Image image) {
		Image = image;
	}
}
