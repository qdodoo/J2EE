package jsp.weixin.msg.Resp;
/**
 * ������Ϣ
 * Author Engineer.Jsp
 * Date 2014.10.08*/
public class MusicMessage extends BaseMessage{
	 // ����  
    private Music Music;  
  
    public Music getMusic() {  
        return Music;  
    }  
  
    public void setMusic(Music music) {  
        Music = music;  
    }  

}
