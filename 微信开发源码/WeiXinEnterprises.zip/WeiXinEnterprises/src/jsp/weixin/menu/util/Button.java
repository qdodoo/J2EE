 package jsp.weixin.menu.util;

/** 
 * ��ť�Ļ��� 
 *  
 *@author Engineer-Jsp 
 *@date 2014.06.23  
 */  
public class Button {  
    private String name;  
  
    public String getName() {  
        return name;  
    }  
  
    public void setName(String name) {  
        this.name = name;  
    }  
}  
