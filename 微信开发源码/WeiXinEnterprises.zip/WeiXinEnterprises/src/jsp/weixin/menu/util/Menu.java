package jsp.weixin.menu.util;

/** 
 * �˵� 
 *  
 *@author Engineer-Jsp 
 *@date 2014.06.23 
 */  
public class Menu {  
    private Button[] button;  
  
    public Button[] getButton() {  
        return button;  
    }  
  
    public void setButton(Button[] button) {  
        this.button = button;  
    }  
}  
